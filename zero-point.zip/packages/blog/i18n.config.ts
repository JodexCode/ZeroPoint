// i18n.config.ts
import lang from './lang/index'
export default {
  legacy: false,
  locale: 'zh',
  fallbackLocale: 'en',
  messages: lang,
}
