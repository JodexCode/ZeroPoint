包管理器：pnpm
packages/blog 是 nuxt4
packages/admin 是 vue3
oxlint
prettier
