<!-- packages/admin/src/layouts/AdminLayout.vue -->
<template>
  <div class="admin-layout">
    <!-- 左侧边栏 -->
    <aside class="sidebar">
      <div class="logo">Blog Admin</div>
      <el-menu
        :default-active="activeMenu"
        router
        background-color="var(--bg-color)"
        text-color="var(--text-secondary)"
        active-text-color="var(--el-color-primary)"
        :collapse="false"
      >
        <el-menu-item index="/dashboard">
          <el-icon><Operation /></el-icon>
          <span>{{ $t('nav.dashboard') }}</span>
        </el-menu-item>
        <el-menu-item index="/articles">
          <el-icon><Document /></el-icon>
          <span>{{ $t('nav.articles') }}</span>
        </el-menu-item>
        <!-- 未来可扩展：评论、用户、设置等 -->
      </el-menu>
    </aside>

    <!-- 主内容区 -->
    <main class="main-content">
      <!-- 顶部栏 -->
      <header class="topbar">
        <!-- 标签页区域（占左侧大部分） -->
        <div class="tabs-container">
          <!-- 暂时留空，后续实现动态标签页 -->
          <span class="placeholder-tabs">{{ $t('common.welcome') }}</span>
        </div>

        <!-- 右侧控制区 -->
        <div class="controls">
          <LocaleSwitcher />
          <ThemeToggle />
          <el-dropdown trigger="click" placement="bottom-end">
            <div class="user-info">
              <el-avatar size="small" :src="userAvatar" />
              <span class="username">{{ authStore.user?.username || 'Admin' }}</span>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="handleLogout">
                  {{ $t('common.logout') }}
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </header>

      <!-- 页面内容 -->
      <div class="page-container">
        <RouterView v-slot="{ Component }">
          <keep-alive>
            <component :is="Component" />
          </keep-alive>
        </RouterView>
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { RouterView } from 'vue-router'
import { Operation, Document } from '@element-plus/icons-vue'
import LocaleSwitcher from '@/components/LocaleSwitcher.vue'
import ThemeToggle from '@/components/ThemeToggle.vue'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()

// 临时头像（可替换为真实头像）
const userAvatar = computed(
  () => 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'
)

// 当前激活的菜单项（根据路由路径）
const activeMenu = computed(() => {
  const path = location.pathname
  if (path.startsWith('/articles')) return '/articles'
  return path === '/' ? '/dashboard' : path
})

const handleLogout = () => {
  authStore.logout()
}
</script>

<style scoped lang="scss">
.admin-layout {
  display: flex;
  height: 100vh;
  overflow: hidden;
}

.sidebar {
  width: 220px;
  background-color: var(--bg-color);
  border-right: 1px solid var(--el-border-color);
  display: flex;
  flex-direction: column;

  .logo {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
    color: var(--text-primary);
    border-bottom: 1px solid var(--el-border-color);
  }

  :deep(.el-menu) {
    border: none;
  }
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.topbar {
  height: 56px;
  padding: 0 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: var(--bg-color);
  border-bottom: 1px solid var(--el-border-color);

  .tabs-container {
    flex: 1;
    display: flex;
    align-items: center;
    margin-right: 16px;

    .placeholder-tabs {
      color: var(--text-secondary);
      font-size: 14px;
    }
  }

  .controls {
    display: flex;
    align-items: center;
    gap: 16px;

    .user-info {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;

      .username {
        color: var(--text-primary);
        font-size: 14px;
      }
    }
  }
}

.page-container {
  flex: 1;
  overflow-y: auto;
  background-color: var(--bg-color);
}
</style>
