// src/stores/auth.ts ✅ 修改 logout 方法
import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getCurrentUser, logoutApi } from '@/apis/auth' // 👈 引入 logoutApi
import { useRouter } from 'vue-router'

export const useAuthStore = defineStore('auth', () => {
  const router = useRouter()
  const isAuthenticated = ref(false)
  const user = ref<{ adminId: number; username: string } | null>(null)
  const loading = ref(false)
  const lastValidatedAt = ref<number | null>(null)
  const VALIDATION_COOLDOWN = 5000

  const checkAuth = async (force = false) => {
    if (loading.value) return false
    const now = Date.now()
    if (!force && lastValidatedAt.value && now - lastValidatedAt.value < VALIDATION_COOLDOWN) {
      return isAuthenticated.value
    }

    loading.value = true
    try {
      const res = await getCurrentUser()
      if (res.success && res.data) {
        isAuthenticated.value = true
        user.value = {
          adminId: res.data.adminId,
          username: res.data.username,
        }
        lastValidatedAt.value = now
        return true
      } else {
        reset()
        return false
      }
    } catch {
      reset()
      return false
    } finally {
      loading.value = false
    }
  }

  // ✅ 修改 logout：调用后端接口 + 清状态 + 跳转
  const logout = async () => {
    try {
      await logoutApi() // 👈 关键：通知后端销毁 session
    } catch (error) {
      console.warn('Logout API failed, still clearing local state', error)
    } finally {
      reset()
      lastValidatedAt.value = null

      router.push('/login')
    }
  }

  const reset = () => {
    isAuthenticated.value = false
    user.value = null
  }

  const handleAuthError = async () => {
    await logout() // 复用带 API 调用的登出逻辑
  }

  return {
    isAuthenticated,
    user,
    loading,
    checkAuth,
    logout, // 现在是 async 函数
    handleAuthError,
  }
})
