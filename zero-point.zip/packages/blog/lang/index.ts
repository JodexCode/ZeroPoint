// lang/index.ts
import en from './en.json';
import zh from './zh.json';

export default {
  en,
  zh,
};
