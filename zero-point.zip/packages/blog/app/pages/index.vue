<template>
  <div>欢迎来到Jodex的技术分享博客</div>
</template>

<script lang="ts" setup></script>

<style scoped></style>
