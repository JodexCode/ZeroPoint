<template>
  <div class="not-found">
    <h1>404 - 页面不存在</h1>
    <p>您访问的页面不存在，请检查 URL 是否正确。</p>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
.not-found {
  text-align: center;
  padding: 50px;
}
</style>
