// packages/blog/server/api/me.get.ts
import { defineEventHandler, getCookie, createError } from 'h3'
import { sessionStore } from '../utils/sessionStore'

export default defineEventHandler(async event => {
  const token = getCookie(event, 'session_token')
  if (!token) {
    throw createError({ statusCode: 401, message: '未登录' })
  }

  const session = await sessionStore.get(token)
  if (!session) {
    throw createError({ statusCode: 401, message: '会话已过期' })
  }

  return {
    success: true,
    data: {
      username: session.username,
      adminId: session.adminId,
    },
  }
})
